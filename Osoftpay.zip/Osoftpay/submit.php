<?php
  require_once 'osoftpay_constants.php';

  //Get The Response Url
  $responseUrl = PATH. '/recipet.php';

  //Concatenate String To Generate The Hash
  // <Merchant_Id class="transactionReference TransactionType Amout res"></Merchant_Id>
  $concatString = MERCHANT_NUMBER.$_POST['TransactionReference'].TRANSACTION_TYPE.AMOUNT.$responseUrl;
   echo $concatString.'<br>';
  //Now Generate The Hash
  $hash = hash('sha512', $concatString);
  print_r($hash);
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Page Title</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" media="screen" href="main.css" />
  <script src="main.js"></script>
</head>
<body>
  <p>You will be redirected to Osoftpay in <span id='count'>5</span> seconds....</p>
  <form action="<?php echo GATEWAY; ?>" id="osoft_form" method="post">
    <input name="TransactionType" value="<?php echo TRANSACTION_TYPE; ?>" type="text" />
    <input name="MerchantNumber" value="<?php echo MERCHANT_NUMBER ?>" type="text" />
    <input name="SiteRedirectURL" value="<?php echo $responseUrl; ?>" type="text" />
    <input name="TransactionReference" value="<?php echo $_POST['TransactionReference']; ?>" type="text" />
    <input name="CustomerName" value="<?php echo $_POST['CustomerName']; ?>" type="text" />
    <input name="CustomerId" value="<?php echo $_POST['CustomerId']; ?>" type="text" />
    <input name="PaymentItemName" value="<?php echo $_POST['PaymentItemName'] ?>" type="text" />
    <input name="Amount" value="<?php echo $_POST['Amount']; ?>" type="text" />
    <input name="Hash" value="<?php echo $hash; ?>" type="text" />
    <input type="submit" value="Pay via OSOFTPAY" />
  </form>

  <script>
    var counter = 5;
    var interval = setInterval(function() {
    counter--;
    // Display 'counter' wherever you want to display it.
    var text = document.getElementById('count');
    text.innerHTML = counter;    
    if (counter == 0) {
        // Display a login box
        document.getElementById('osoft_form').submit();
        clearInterval(interval);
    }
}, 1000);
  </script>
</body>
</html>