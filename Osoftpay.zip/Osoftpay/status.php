<?php
// This Is For Test Purpose So You Can Understand How To Query Your Transaction Status
// This Transaction We Are Checking The Status For Has Already Been Registered The Hash Was Copied 
// So The Variables Are Hard Coded
// Visit developer.osoftpay.net For More Understanding 

$url = "https://developer.osoftpay.net/api/TestPublicPayments?TransactionNumber=" . 47365453 . "&Amount=" . 5000;

// The hash Already Been Generated
$header = [
  "Accept: application/json",
  "Hash: 1851b0005e7a96f58146eb754ee4c9811598641e099c5a8b9de1bf6dcc3314b2e68ba5d1b145995c7c7f30f349a11171d9dc12698b2f200a235558dd304e6562"
];

$curl = curl_init();

// DISABLE SSL SECURITY
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

// WILL RECIEVE RESPONSE
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

// SET THE HEADER
curl_setopt($curl, CURLOPT_HTTPHEADER, $header);

// SET THE URL
curl_setopt($curl, CURLOPT_URL, $url);

// SET THE VARIABLE
$response = curl_exec($curl);

// TRANSFORM RESPONSE TO AN ARRAY
$response = json_decode($response, true);

print_r($response);
echo 'Trasaction Id:'. $response['TransactionReference'];
