<?php 
define('MERCHANT_NUMBER', 'g3ggdgsi1.gns4g.');
define('PATH', 'http://'.$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF']));
define('TRANSACTION_TYPE', 2);
// The Url To Test Payments
define('GATEWAY', 'https://developer.osoftpay.net/api/TestPublicPayments');
