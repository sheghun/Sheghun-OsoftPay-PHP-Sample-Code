<nav class="navbar navbar-light justify-content-between" style="background-color:#008cba !important;">
  <a class="navbar-brand">
    <img src="assets/logo.png" alt="" srcset="">
  </a>
  <div class="">
    <ul class="navbar-nav mr-5">
      <li class="nav-item">
        <a href="status.php" class="nav-link" style="color: white!important;">Check Status</a>
      </li>    
    </ul>
  </div>
</nav>