<?php 
  require_once 'osoftpay_constants.php';
  if( isset($_GET['TransactionReference'])) {
    echo $_GET['TransactionReference'];
    echo $_GET['PayRef'];
  }