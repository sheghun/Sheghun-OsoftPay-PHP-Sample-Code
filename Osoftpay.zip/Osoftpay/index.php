<?php
/**
 * @author Oladiran Segun Solomon <sheghunoladiran9@gmail.com>
 * @link https://github.com/sheghun
 */

  require_once 'osoftpay_constants.php';
  $transaction_reference = uniqid('', true);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <title>Document</title>
  <style>
    
  </style>
</head>
<body>
  <?php
    require_once 'includes/header.php';
  ?>
  <div class="container">
    <div class="row">
    <div class="col-md-9 offset-md-2">
      <div class="container mt-5">
        <form action="submit.php" method="post" class="text-left">
          <div class="form-group row">
            <label for="CustomerName" class="col-sm-5">CustomerName</label>
            <input type="text" class="form-control col-sm-5" name="CustomerName" >
          </div>

          <div class="form-group row">
            <label for="CustomerId" class="col-sm-5">Email</label>
            <input type="text" class="form-control col-sm-5" name="CustomerId" id="">
          </div>

          <div class="form-group row">
            <label for="PaymentItemName" class="col-sm-5">PaymentItemName</label>
            <input type="text" name="PaymentItemName" class="form-control col-sm-5" id="">
          </div>
          <?php
          ?>
          <div class="form-group row">
            <label for="TransactionReference" class="col-sm-5">TransactionReference</label>
            <input type="text" value="47365453" class="form-control col-sm-5" name="TransactionReference" id="">
          </div>

          <div class="form-group row">
            <label for="Amount" class="col-sm-5">Amount</label>
            <input type="number" class="form-control col-sm-5" value="<?php echo AMOUNT; ?>" name="Amount" id="">
          </div>
          <button type="submit" class="btn justify-content-end" style="cursor:pointer;background-color:#008cba !important" >Make Payments</button>
        </form> 
      </div>   
    </div>
    </div>  
  </div>  
</body>
</html>